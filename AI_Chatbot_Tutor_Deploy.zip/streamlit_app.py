
import streamlit as st
import pandas as pd
import numpy as np
import joblib
import os

st.set_page_config(page_title="AI Chatbot Tutor", page_icon="🤖", layout="wide")
st.title("🧠 AI Chatbot Tutor - Multi-turn Chat")

st.markdown("Welcome! Type a sentence and get feedback from your personalized AI tutor.")

model_path = "artifacts/RandomForest_model.joblib"
preprocessor_path = "artifacts/preprocessor.joblib"

if os.path.exists(model_path) and os.path.exists(preprocessor_path):
    rf_model = joblib.load(model_path)
    preprocessor = joblib.load(preprocessor_path)
    st.success("Model and preprocessor loaded ✅")
else:
    rf_model = None
    preprocessor = None
    st.warning("No trained model found. Replace artifacts/ with your models.")

if "chat_history" not in st.session_state:
    st.session_state.chat_history = []

def extract_features_from_text(text):
    text = text.lower()
    features = {}
    features['length'] = len(text)
    features['num_words'] = len(text.split())
    features['num_commas'] = text.count(',')
    features['num_excl'] = text.count('!')
    return pd.DataFrame([features])

def get_feedback_from_text(text):
    X_input = extract_features_from_text(text)
    if rf_model and preprocessor:
        X_proc = preprocessor.transform(X_input)
        prob = rf_model.predict_proba(X_proc)[:,1][0]
        if prob < 0.4:
            feedback = f"Struggling (success {prob:.2f}). Focus on grammar."
        elif prob < 0.8:
            feedback = f"Doing okay (success {prob:.2f}). Try this practice sentence."
        else:
            feedback = f"Great! Likely success (success {prob:.2f}). Try a harder sentence."
        return feedback
    else:
        feedback_options = ["Excellent work! 🎉","Check your grammar ✏️","Try again 🔄","You're improving! 🚀"]
        return np.random.choice(feedback_options)

user_input = st.text_input("Type your sentence:")

if st.button("Send") and user_input.strip() != "":
    feedback = get_feedback_from_text(user_input)
    st.session_state.chat_history.append(("You", user_input))
    st.session_state.chat_history.append(("Tutor", feedback))

st.subheader("Conversation")
for speaker, message in st.session_state.chat_history:
    if speaker == "You":
        st.markdown(f"**You:** {message}")
    else:
        st.markdown(f"**Tutor:** {message}")

if st.button("Reset Chat"):
    st.session_state.chat_history = []
    st.experimental_rerun()
